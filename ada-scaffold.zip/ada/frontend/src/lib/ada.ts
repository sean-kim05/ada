// Mirror of the backend AgentEvent. Keep in sync with runtime/events.py.

export type EventType =
  | "plan"
  | "tool_call"
  | "tool_result"
  | "message"
  | "log"
  | "final"
  | "error";

export interface AgentEvent {
  run_id: string;
  agent_id: string;
  seq: number;
  type: EventType;
  payload: Record<string, unknown>;
  model: string | null;
  latency_ms: number | null;
  tokens: number | null;
  cost_usd: number | null;
  ts: number;
}

const API = "http://127.0.0.1:8000";
const WS = "ws://127.0.0.1:8000";

// Start a run and stream its events. onEvent fires for each; resolves when the run ends.
export async function startRun(
  message: string,
  onEvent: (e: AgentEvent) => void
): Promise<void> {
  const resp = await fetch(`${API}/api/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message }),
  });
  const { run_id } = await resp.json();

  return new Promise((resolve) => {
    const ws = new WebSocket(`${WS}/api/runs/${run_id}/ws`);
    ws.onmessage = (msg) => {
      const event: AgentEvent = JSON.parse(msg.data);
      onEvent(event);
      if (event.type === "final" || event.type === "error") {
        ws.close();
        resolve();
      }
    };
    ws.onerror = () => resolve();
  });
}
