import { useState, useRef, useEffect } from "react";
import { startRun, type AgentEvent } from "./lib/ada";

interface ChatMsg {
  role: "user" | "ada";
  text: string;
}

const NAV = ["Chat", "Fleet", "Trace", "Arena", "Terminal", "Calendar", "Tasks", "Docs"];

export default function App() {
  const [msgs, setMsgs] = useState<ChatMsg[]>([]);
  const [events, setEvents] = useState<AgentEvent[]>([]);
  const [input, setInput] = useState("");
  const [running, setRunning] = useState(false);
  const traceEnd = useRef<HTMLDivElement>(null);

  useEffect(() => {
    traceEnd.current?.scrollIntoView({ behavior: "smooth" });
  }, [events]);

  async function send() {
    const text = input.trim();
    if (!text || running) return;
    setMsgs((m) => [...m, { role: "user", text }]);
    setInput("");
    setEvents([]);
    setRunning(true);

    await startRun(text, (e) => {
      setEvents((prev) => [...prev, e]);
      if (e.type === "final") {
        setMsgs((m) => [...m, { role: "ada", text: String(e.payload.text ?? "") }]);
      }
      if (e.type === "error") {
        setMsgs((m) => [
          ...m,
          { role: "ada", text: `Something broke: ${e.payload.message}` },
        ]);
      }
    });
    setRunning(false);
  }

  const totals = summarize(events);

  return (
    <div style={S.shell}>
      {/* ── Left rail ────────────────────────────────── */}
      <aside style={S.rail}>
        <div style={S.brand}>
          <span style={{ fontSize: 20, fontWeight: 700 }}>Ada</span>
          <div style={S.status}>
            <span className="pulse" />
            <span className="eyebrow">online</span>
          </div>
        </div>
        <nav style={S.nav}>
          {NAV.map((n) => (
            <div key={n} style={{ ...S.navItem, ...(n === "Chat" ? S.navActive : {}) }}>
              {n}
            </div>
          ))}
        </nav>
        <div style={S.railFoot}>
          <Stat label="spend today" value={`$${totals.cost.toFixed(3)}`} />
          <Stat label="tool calls" value={String(totals.tools)} />
          <Stat label="routing" value={`${totals.local} local · ${totals.api} api`} />
        </div>
      </aside>

      {/* ── Chat ─────────────────────────────────────── */}
      <main style={S.chat}>
        <div style={S.chatHead}>
          <span className="eyebrow">Chat</span>
          <span className="eyebrow">session · today</span>
        </div>
        <div style={S.chatBody}>
          {msgs.length === 0 && (
            <div style={S.empty}>
              Ask Ada to do something. Try:{" "}
              <span className="amber">"add a task to prep for the Joby panel, then
              list my tasks"</span>
            </div>
          )}
          {msgs.map((m, i) => (
            <Bubble key={i} msg={m} />
          ))}
          {running && <div style={S.thinking}>Ada is working…</div>}
        </div>
        <div style={S.inputRow}>
          <input
            style={S.input}
            value={input}
            placeholder="Message Ada…"
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && send()}
          />
          <button style={S.send} onClick={send} disabled={running}>
            →
          </button>
        </div>
      </main>

      {/* ── Agent Trace (the hero) ───────────────────── */}
      <section style={S.trace}>
        <div style={S.traceHead}>
          <span className="eyebrow">Agent Trace</span>
          <span style={S.traceStatus}>
            <span
              className="pulse"
              style={{
                background: running ? "var(--amber)" : "var(--green)",
                boxShadow: `0 0 8px ${running ? "var(--amber)" : "var(--green)"}`,
              }}
            />
            <span className="eyebrow">{running ? "running" : "done"}</span>
          </span>
        </div>
        {events[0] && (
          <div style={S.traceMeta} className="mono">
            {events[0].run_id} · plan → act → observe
          </div>
        )}
        <div style={S.traceBody}>
          {events.length === 0 && (
            <div style={S.empty}>Steps stream here as Ada thinks.</div>
          )}
          {events.map((e, i) => (
            <TraceStep key={i} e={e} />
          ))}
          <div ref={traceEnd} />
        </div>
        {events.length > 0 && (
          <div style={S.traceFoot} className="mono">
            {totals.tools} tools · ${totals.cost.toFixed(3)} ·{" "}
            {totals.local} local · {totals.api} api
          </div>
        )}
      </section>
    </div>
  );
}

/* ── Pieces ─────────────────────────────────────────── */

function Bubble({ msg }: { msg: ChatMsg }) {
  const isUser = msg.role === "user";
  return (
    <div style={{ ...S.bubbleRow, justifyContent: isUser ? "flex-end" : "flex-start" }}>
      {!isUser && <div style={S.avatar}>A</div>}
      <div style={{ ...S.bubble, ...(isUser ? S.bubbleUser : S.bubbleAda) }}>
        {msg.text}
      </div>
    </div>
  );
}

function TraceStep({ e }: { e: AgentEvent }) {
  const lat = e.latency_ms != null ? `${e.latency_ms}ms` : "";
  const isLocal = e.model?.includes("local");

  if (e.type === "tool_call") {
    return (
      <div style={S.step}>
        <div style={S.stepHead}>
          <span style={S.tag}>TOOL</span>
          <span className="mono" style={{ color: "var(--text)" }}>
            {String(e.payload.tool)}
          </span>
          <span style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
            {e.model && (
              <span className={`badge ${isLocal ? "local" : "claude"}`}>
                {isLocal ? "QWEN-14B · LOCAL" : "CLAUDE"}
              </span>
            )}
            <span className="mono faint">{lat}</span>
          </span>
        </div>
        <div style={S.stepDetail}>{fmt(e.payload.input)}</div>
      </div>
    );
  }
  if (e.type === "tool_result") {
    return (
      <div style={S.subStep}>
        <span className="mono faint">└ {fmt(e.payload.output)}</span>
        <span className="mono faint" style={{ marginLeft: "auto" }}>{lat}</span>
      </div>
    );
  }
  if (e.type === "final") {
    return (
      <div style={S.step}>
        <div style={S.stepHead}>
          <span style={{ ...S.tag, ...S.tagFinal }}>FINAL</span>
          <span className="badge claude" style={{ marginLeft: "auto" }}>CLAUDE</span>
        </div>
        <div style={S.stepDetail}>{String(e.payload.text ?? "")}</div>
      </div>
    );
  }
  if (e.type === "error") {
    return (
      <div style={S.step}>
        <span style={{ ...S.tag, color: "#e06b6b", borderColor: "#e06b6b" }}>ERROR</span>
        <div style={S.stepDetail}>{String(e.payload.message ?? "")}</div>
      </div>
    );
  }
  return null;
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div style={S.stat}>
      <span className="eyebrow">{label}</span>
      <span className="mono amber" style={{ fontSize: 13 }}>{value}</span>
    </div>
  );
}

/* ── helpers ────────────────────────────────────────── */

function fmt(v: unknown): string {
  if (v == null) return "";
  if (typeof v === "string") return v;
  return JSON.stringify(v);
}

function summarize(events: AgentEvent[]) {
  let cost = 0,
    tools = 0,
    local = 0,
    api = 0;
  for (const e of events) {
    if (e.cost_usd) cost += e.cost_usd;
    if (e.type === "tool_call") {
      tools++;
      if (e.model?.includes("local")) local++;
      else api++;
    }
  }
  return { cost, tools, local, api };
}

/* ── styles ─────────────────────────────────────────── */

const S: Record<string, React.CSSProperties> = {
  shell: {
    display: "grid",
    gridTemplateColumns: "220px 1fr 460px",
    height: "100vh",
    gap: 1,
    background: "var(--line)",
  },
  rail: {
    background: "var(--bg)",
    display: "flex",
    flexDirection: "column",
    padding: "20px 16px",
  },
  brand: { marginBottom: 28 },
  status: { display: "flex", alignItems: "center", gap: 7, marginTop: 6 },
  nav: { display: "flex", flexDirection: "column", gap: 2, flex: 1 },
  navItem: {
    padding: "9px 12px",
    borderRadius: 5,
    color: "var(--text-dim)",
    cursor: "pointer",
    fontSize: 14,
  },
  navActive: { background: "var(--amber-soft)", color: "var(--amber)" },
  railFoot: {
    display: "flex",
    flexDirection: "column",
    gap: 12,
    borderTop: "1px solid var(--line)",
    paddingTop: 16,
  },
  stat: { display: "flex", flexDirection: "column", gap: 3 },

  chat: { background: "var(--bg)", display: "flex", flexDirection: "column" },
  chatHead: {
    display: "flex",
    justifyContent: "space-between",
    padding: "18px 24px",
    borderBottom: "1px solid var(--line-soft)",
  },
  chatBody: { flex: 1, overflowY: "auto", padding: "24px", display: "flex", flexDirection: "column", gap: 18 },
  empty: { color: "var(--text-faint)", fontSize: 13, lineHeight: 1.6 },
  thinking: { color: "var(--amber)", fontSize: 13, fontFamily: "var(--mono)" },
  bubbleRow: { display: "flex", gap: 10, alignItems: "flex-start" },
  avatar: {
    width: 26, height: 26, borderRadius: 5,
    background: "var(--amber-soft)", color: "var(--amber)",
    display: "flex", alignItems: "center", justifyContent: "center",
    fontFamily: "var(--mono)", fontSize: 12, flexShrink: 0,
  },
  bubble: { maxWidth: "78%", padding: "11px 14px", borderRadius: 8, lineHeight: 1.55 },
  bubbleUser: { background: "var(--panel-2)", border: "1px solid var(--line)" },
  bubbleAda: { background: "transparent", border: "1px solid var(--line-soft)" },
  inputRow: {
    display: "flex",
    gap: 10,
    padding: "16px 24px",
    borderTop: "1px solid var(--line-soft)",
  },
  input: {
    flex: 1,
    background: "var(--panel)",
    border: "1px solid var(--line)",
    borderRadius: 8,
    padding: "12px 14px",
    color: "var(--text)",
    fontFamily: "var(--sans)",
    fontSize: 14,
    outline: "none",
  },
  send: {
    background: "var(--amber)",
    color: "#1a1205",
    border: "none",
    borderRadius: 8,
    width: 44,
    fontSize: 18,
    cursor: "pointer",
    fontWeight: 700,
  },

  trace: { background: "var(--panel)", display: "flex", flexDirection: "column" },
  traceHead: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "18px 20px",
    borderBottom: "1px solid var(--line-soft)",
  },
  traceStatus: { display: "flex", alignItems: "center", gap: 7 },
  traceMeta: { fontSize: 11, color: "var(--text-faint)", padding: "10px 20px 0" },
  traceBody: { flex: 1, overflowY: "auto", padding: "16px 20px", display: "flex", flexDirection: "column", gap: 14 },
  step: { display: "flex", flexDirection: "column", gap: 6 },
  stepHead: { display: "flex", alignItems: "center", gap: 10 },
  tag: {
    fontFamily: "var(--mono)",
    fontSize: 10,
    letterSpacing: "0.1em",
    padding: "3px 7px",
    border: "1px solid var(--line)",
    borderRadius: 3,
    color: "var(--text-dim)",
  },
  tagFinal: { color: "var(--amber)", borderColor: "rgba(232,163,61,0.4)" },
  stepDetail: { color: "var(--text-dim)", fontSize: 13, lineHeight: 1.5, paddingLeft: 2 },
  subStep: { display: "flex", alignItems: "center", gap: 6, fontSize: 12, paddingLeft: 4 },
  traceFoot: {
    padding: "14px 20px",
    borderTop: "1px solid var(--line-soft)",
    fontSize: 12,
    color: "var(--text-dim)",
  },
};
