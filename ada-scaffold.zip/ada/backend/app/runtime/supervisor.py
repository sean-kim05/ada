"""Supervisor — owns running agents. In M1 it launches a single Ada run per request. In
M2 this is where concurrent runs and spawn_agent live; the Fleet view reads its registry.

A Run is one task given to one agent. We launch it as an asyncio task so the HTTP request
returns immediately and events stream over the WebSocket."""

from __future__ import annotations

import asyncio
import uuid
from dataclasses import dataclass, field
from typing import Literal

from app.agents import ada
from app.runtime.bus import Emitter
from app.runtime.events import EventType

RunStatus = Literal["running", "done", "error"]


@dataclass
class Run:
    run_id: str
    agent_id: str
    prompt: str
    status: RunStatus = "running"
    task: asyncio.Task | None = field(default=None, repr=False)


class Supervisor:
    def __init__(self) -> None:
        self._runs: dict[str, Run] = {}

    def list_runs(self) -> list[Run]:
        return list(self._runs.values())

    def start_ada(self, prompt: str) -> Run:
        run_id = uuid.uuid4().hex[:8]
        run = Run(run_id=run_id, agent_id="ada-core", prompt=prompt)
        self._runs[run_id] = run
        run.task = asyncio.create_task(self._drive(run))
        return run

    async def _drive(self, run: Run) -> None:
        emitter = Emitter(run.run_id, run.agent_id)
        try:
            await ada.run(run.prompt, emitter)
            run.status = "done"
        except Exception as exc:  # noqa: BLE001 - surface any failure as an event
            run.status = "error"
            await emitter.emit(EventType.ERROR, {"message": str(exc)})


supervisor = Supervisor()
