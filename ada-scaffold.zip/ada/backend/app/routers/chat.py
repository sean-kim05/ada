"""HTTP + WebSocket surface for the dashboard.

POST /api/chat        -> start an Ada run, returns { run_id }
WS   /api/runs/{id}/ws -> stream that run's AgentEvents live
GET  /api/runs        -> current fleet (for M2's Fleet view; useful now for debugging)
"""

from __future__ import annotations

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from pydantic import BaseModel

from app.runtime.bus import subscribe
from app.runtime.events import EventType
from app.runtime.supervisor import supervisor

router = APIRouter()


class ChatRequest(BaseModel):
    message: str


@router.post("/api/chat")
async def chat(req: ChatRequest) -> dict:
    run = supervisor.start_ada(req.message)
    return {"run_id": run.run_id}


@router.get("/api/runs")
async def runs() -> list[dict]:
    return [
        {"run_id": r.run_id, "agent_id": r.agent_id, "status": r.status,
         "prompt": r.prompt}
        for r in supervisor.list_runs()
    ]


@router.websocket("/api/runs/{run_id}/ws")
async def run_ws(websocket: WebSocket, run_id: str) -> None:
    await websocket.accept()
    try:
        async for event in subscribe(run_id):
            await websocket.send_json(event.model_dump(mode="json"))
            if event.type in (EventType.FINAL, EventType.ERROR):
                break
    except WebSocketDisconnect:
        pass
